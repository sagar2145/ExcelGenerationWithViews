package com.excel.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import com.sap.db.annotations.Immutable;

@Entity
@Immutable
public class Student145 {
   
	@Id
	@Column(name="rollNo")
	private int rollNo;
	private String name;
	private double percentage;	
	private  double english;
	private double maths;
	
	
	public Student145() {
		// TODO Auto-generated constructor stub
	}


	public Student145(int rollNo, String name, double percentage, double english, double maths) {
		super();
		this.rollNo = rollNo;
		this.name = name;
		this.percentage = percentage;
		this.english = english;
		this.maths = maths;
	}


	public int getRollNo() {
		return rollNo;
	}


	public void setRollNo(int rollNo) {
		this.rollNo = rollNo;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public double getPercentage() {
		return percentage;
	}


	public void setPercentage(double percentage) {
		this.percentage = percentage;
	}


	public double getEnglish() {
		return english;
	}


	public void setEnglish(double english) {
		this.english = english;
	}


	public double getMaths() {
		return maths;
	}


	public void setMaths(double maths) {
		this.maths = maths;
	}


	
}
