package com.excel.controller;

import java.io.IOException;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.excel.entity.ClassA;
import com.excel.entity.ClassB;
import com.excel.entity.ClassC;
import com.excel.entity.List121;
import com.excel.entity.Sample;
import com.excel.entity.Student121;
import com.excel.entity.StudentInfo;
import com.excel.response.Response;
import com.excel.service.Service1;


@Service
@RestController
@RequestMapping(value="/purchase", produces = "application/json" )
public class Controller {
	
	@Autowired
	Service1 service1;
	
   	// create excel sheet with all specified columns and data
	@RequestMapping(value = "/create", method = RequestMethod.POST)
	public Response createExcel(@RequestBody List<StudentInfo> studentInfo){
	System.out.println("controller : "+studentInfo.get(1).getRollNo());
		return 	service1.createExcel(studentInfo);
		
	}

	// add data to StudentInfo table
	@RequestMapping(value = "/add", method = RequestMethod.POST, consumes = "application/json")
	public Response add(@RequestBody StudentInfo studentInfo){
		return 	service1.add(studentInfo);
	}
	
	// add data to sample table
	@RequestMapping(value = "/addSample", method = RequestMethod.POST, consumes = "application/json")
	public Response addSample(@RequestBody Sample sample){
		return 	service1.addSample(sample);	
	}
	
	// add data to sample table with batch processing condition
	@RequestMapping(value = "/addS1", method = RequestMethod.POST, consumes = "application/json")
	public Response addS1(@RequestBody Sample sample){
		return 	service1.addS1(sample);	
	}
	
	// adding data from excel to DB
	@RequestMapping(value = "/addToDb", method = RequestMethod.POST, consumes = "application/json")
	public String addToDb(@RequestBody ClassA path) throws IOException{
	System.out.println("controller");
		return 	service1.addDataToDB(path.getFile());	
	}
	
	// update a specific row in excel sheet
	@RequestMapping(value = "/update121", method = RequestMethod.POST, consumes = "application/json")
	public Response update121(@RequestBody StudentInfo studentInfo){
		return 	service1.updateExcel(studentInfo);
	}
	
	// update sample table with batch processing condition
	@RequestMapping(value = "/updateSample", method = RequestMethod.POST, consumes = "application/json")
	public Response updateSample(@RequestBody Sample sample){
		return 	service1.updateSample(sample);
	}
	
	// update sample table 
	@RequestMapping(value = "/updateS1", method = RequestMethod.POST, consumes = "application/json")
	public Response updateS1(@RequestBody Sample sample){
		return 	service1.updateS1(sample);
	}
	
	// creating excel sheet and adding data from table
	@RequestMapping(value = "/addToExcel", method = RequestMethod.GET)
	public Response dbToExcel(){
		return 	service1.dbToExcel();
	}
	
	//adding data to ClassA table
	@RequestMapping(value = "/addToClassA", method = RequestMethod.POST, consumes = "application/json")
	public Response addClassA(@RequestBody ClassA classA){
		return 	service1.addToClassA(classA);
	}
	
	// adding data to ClassB table
	@RequestMapping(value = "/addToClassB", method = RequestMethod.POST, produces = "application/json")
	public Response addClassB(@RequestBody ClassB classB){
		return 	service1.addToClassB(classB);
	}
	
	//adding data to ClassC table
	@RequestMapping(value = "/addClassC", method = RequestMethod.POST, produces = "application/json")
	public Response addClassC(@RequestBody ClassC classC){
		return 	service1.addToClassC(classC);
		
	}
	
	// generating excel with first two columns  and adding data from table
	@RequestMapping(value = "/addData", method = RequestMethod.GET, consumes = "application/json")
	public String addClassData() throws IOException{
		return 	service1.addClassData();
	}
	
	// creating view with columns of only one table
	@RequestMapping(value = "/view", method = RequestMethod.GET, consumes = "application/json")
	public Response view() {
		return service1.view();
	}
	
	// fetching from view ABC
	@RequestMapping(value = "/fetchView", method = RequestMethod.GET, consumes = "application/json")
	public List<ClassA> fetchingview() {
		return service1.fetchingView();
	}
	
	// book view with two tables combined
	@RequestMapping(value = "/combineView", method = RequestMethod.GET, consumes = "application/json")
	public Response combineView() {
		return service1.combineView();
	}

	// inserting into Book View
	@RequestMapping(value = "/addToBookView", method = RequestMethod.POST, consumes = "application/json")
	public Response addToCombine(@RequestBody List121 list121) {
		return service1.addToCombineView(list121);
	}

	// getting data from bookView
	@RequestMapping(value = "/getBookView1", method = RequestMethod.GET, consumes = "application/json")
	public List<List121> getViewData() {
		return service1.getViewData();
	}

	// updating data from bookView
	@RequestMapping(value = "/updateBookView", method = RequestMethod.POST, consumes = "application/json")
	public Response updateBookView(@RequestBody List121 list121) {
		return service1.updateBookView(list121);
	}

	// deleting a record from bookView
	@RequestMapping(value = "/deleteBookView", method = RequestMethod.POST, consumes = "application/json")
	public Response deleteBookView(@RequestBody List121 list121) {
		return service1.deleteBookView(list121);
	}

	@RequestMapping(value = "/testing1", method = RequestMethod.POST, consumes = "application/json")
	public Response testing(@RequestBody List121 list121) {
		return service1.testing(list121);
	}
	
	// creating student view
	@RequestMapping(value = "/createStudentView", method = RequestMethod.GET, consumes = "application/json")
	public Response createStudentView(){
		return 	service1.createStudentView();
	}
	
	// adding data to studentView
	@RequestMapping(value = "/addToStudentView", method = RequestMethod.POST, consumes = "application/json")
	public Response addToStudentView(@RequestBody List121 list121) {
		return service1.addToStudentView(list121);
	}
	
	// getting data from studentView
	@RequestMapping(value = "/getStudentView", method = RequestMethod.GET, consumes = "application/json")
	public List<List121> getStudentViewData() {
		return service1.getStudentViewData();
	}
	
	// updating data in studentView
	@RequestMapping(value = "/updateStudentView", method = RequestMethod.POST, consumes = "application/json")
	public Response updateStudentView(@RequestBody List121 list121) {
		return service1.updateStudentView(list121);
	}
	
	// delete row in a studentView
	@RequestMapping(value = "/deleteStudentView", method = RequestMethod.POST, consumes = "application/json")
	public Response deleteStudentView(@RequestBody List121 list121) {
		return service1.deleteStudentView(list121);
	}

	@RequestMapping(value = "/CreateView", method = RequestMethod.GET, consumes = "application/json")
	public Response createView() {
		return service1.createView();
	}
	
	
	@RequestMapping(value = "/view1", method = RequestMethod.GET, consumes = "application/json")
	public Response view1() {
		return service1.view1();
	}
	
	
	@RequestMapping(value = "/createTrigger", method = RequestMethod.GET, consumes = "application/json")
	public Response fcreateTrigger() {
		return service1.createTrigger();
	}
	
	@RequestMapping(value = "/addToView", method = RequestMethod.POST, consumes = "application/json")
	public Response addToView(@RequestBody ClassA classA){
		return 	service1.addToview(classA);
	}
	
	@RequestMapping(value = "/updateView", method = RequestMethod.POST, consumes = "application/json")
	public Response updateView(@RequestBody Student121 classA){
		return 	service1.updateview(classA);
	}
	
	
	// adding data to existing excel sheet
	@RequestMapping(value = "/addToExcel", method = RequestMethod.POST, consumes = "application/json")
	public String addToExcel(@RequestBody List<ClassA> classA){
		return 	service1.addDataToExcel(classA);
	}
	
	// generic method to add data to existing excel sheet
	@RequestMapping(value = "/addGenericToExcel", method = RequestMethod.POST, consumes = "application/json")
	public String addGenericToExcel(@RequestBody List121 list121){
		return 	service1.addGenericDataToExcel(list121);
	}
	
	// generic method to add data to table
	@RequestMapping(value = "/addObj", method = RequestMethod.POST, consumes = "application/json")
	public Response generic(@RequestBody List121 list) throws IOException{
		System.out.println("Object controller");
		return 	service1.generic(list);
		}
	
	// generate excel with base64
	@RequestMapping(value = "/upload", method = RequestMethod.POST, consumes = "application/json")
	public String upload(@RequestBody ClassA base64){	
		return 	service1.upload(base64.getFile());
	}
	
    // adding data to classA table
	@RequestMapping(value = "/addObjA", method = RequestMethod.POST, consumes = "application/json")
	public Response addObjA(@RequestBody List121 objA){	
		return 	service1.addObjA(objA);
	}
	
	// adding data to classB table
	@RequestMapping(value = "/addObjB", method = RequestMethod.POST, consumes = "application/json")
	public Response addObjB(@RequestBody List121 objB){	
		return 	service1.addObjB(objB);
	}
	
	// adding data to classC table
	@RequestMapping(value = "/addObjC", method = RequestMethod.POST, consumes = "application/json")
	public Response addObjC(@RequestBody List121 objC){
		return 	service1.addObjC(objC);
	}
	
	// generic method to create excel sheet with only two columns
	@RequestMapping(value = "/addGeneric", method = RequestMethod.POST, consumes = "application/json")
	public String addGenericData(@RequestBody List121 list121){
		return 	service1.addGenericData(list121);
	}
	
	@RequestMapping(value = "/addGeneric121", method = RequestMethod.POST, consumes = "application/json")
	public String addGenericData121(@RequestBody List121 list121){
		return 	service1.addGenericData121(list121);
	}
}

/* // add only purchaseOrderHeader
@RequestMapping(value = "/addOrder", method = RequestMethod.POST, consumes = "application/json")
public Response showOrders(@RequestBody StudentInfo studentInfo){

	return 	service1.addPurchaseOrder(studentInfo);
	
}*/
