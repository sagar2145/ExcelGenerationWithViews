package com.excel.test;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

public class Test {

	public static void main(String[] args) throws IOException, URISyntaxException {
		// TODO Auto-generated method stub
		String s2="delete from BOOK where rollNo="+2;

         System.out.println("query " +s2);
/*         String url="www.fb.com";
*/         String s="C:/Users/sagar.chidre/Pictures/Capture1.PNG";
/*         Desktop.getDesktop().browse(new URI(url)); 
*/         Desktop.getDesktop().open(new File(s));
	}

}
